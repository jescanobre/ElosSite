This typographic product and its digital files are (c)2001 Nerfect Type Laboratories and Britton Walters.

As it took quite a bit of time and effort to create this typeface we are now equally dedicated to it's proper and legal use. Please be warned that you will accept the conditions and terms of this license agreement by downloading, purchasing, or installing this font or family of fonts. In return for a license to use these digital files you agree to the following terms and conditions. Please keep this file with our fonts or your license will be terminated immediately.

1. DO NOT COPY OR DISTRIBUTE OR FONTS WITHOUT OUR PERMISSION
You may not copy or duplicate any of our fonts in any form (except for backup purposes) unless you get written permission from Britton Walters. This also means that you will not distribute these fonts and other included digital files on your website, cd-rom, etc. We can handle that ourselves.

2. GIVE US A LITTLE CREDIT
When production credits are listed please include us. We love to see our fonts used in cool projects and we think as our font made your final piece what it is we could get a credit in these production notes. Send us a sample if you can and you'll make our day.

3. YOU GET WHAT YOU PAY AND THEN SOME
We try our best to create fonts you can type complete English sentences with, and our top-notch pay fonts often carry a full complement of foreign language characters. You will find however that many of our free fonts lack some punctuation or numerals. Often times these fonts are created for limited uses or as pure display faces more ideal for headlines than body copy. What did you expect for free?

4. OUR FONT IS PERFECT FOR YOUR NEW LOGO, BUT MAYBE NOT

Please do not use any of our dingbats as or as part of a logo. They are meant to be used with our typefaces and at certain sizes. The sets included with or as fonts on their own are not meant to be corporate identities. Please contact us for permission if you just must use one of our images as part of your logo. In most cases we can provide you with artwork to better suit your needs, and for reasonable rates.

5. IF ICONS CAME WITH THIS FONT (AND THEY OFTEN DO)
Each font we produce comes with a custom icon that we created. In some cases an entire set of icons will be included. Please feel free to spruce up you desktop with them, but don't use them for your own commercial uses. If one of icons would be perfect for one of you digital projects please get our permission to use it.

6. TERMS
This license is effective until terminated.  We have the right to terminate your license immediately if you fail to comply with any term of this agreement.  

7. IT AIN'T OUR FAULT
In no event will we, the makers of the font(s), be liable to you for any consequential or incidental damages, including any lost revenue, profits, goodwill or savings, or for any claim by any third party.
 
HOW TO INSTALL FONTS ON MACHINES RUNNING WINDOWS 95, 98, or 2000:

1.From the Control Panel open the Fonts folder.
2.On the File menu, click Install New Font.
3. Click the drive and folder that contain the fonts you want to add.
4.To select more than one font to add, press and hold down the CTRL key, click the fonts you want, and then click on OK. To select a range of fonts in the list, press and hold down the SHIFT key while dragging the cursor over the fonts. To add fonts from a network drive without using disk space on your computer, make sure Copy fonts to Fonts folder is not checked.

WE LOVE E-MAIL
mailbox@nerfect.com


